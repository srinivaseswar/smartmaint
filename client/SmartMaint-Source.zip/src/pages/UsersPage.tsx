import { Users as UsersIcon, ShieldCheck, Mail, Phone, Plus } from 'lucide-react';
import { PageHeader } from '@/components/ui/Toolbar';
import { Badge } from '@/components/ui/Badge';
import { users } from '@/data/seed';
import { ROLE_MAP } from '@/lib/rbac';

export function UsersPage() {
  return (
    <div>
      <PageHeader
        title="User Management"
        subtitle="Manage system users, roles, and permissions"
        actions={<button className="btn-primary"><Plus className="h-4 w-4" /> Add User</button>}
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {users.map((u) => (
          <div key={u.id} className="card card-hover p-5">
            <div className="flex items-start gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold text-white" style={{ backgroundColor: u.avatar_color }}>
                {u.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-slate-900 dark:text-white">{u.name}</p>
                <Badge tone="primary" className="mt-1">{ROLE_MAP[u.role]?.name || u.role}</Badge>
              </div>
            </div>
            <div className="mt-4 space-y-1.5">
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400"><Mail className="h-3.5 w-3.5" /> {u.email}</div>
              {u.phone && <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400"><Phone className="h-3.5 w-3.5" /> {u.phone}</div>}
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400"><ShieldCheck className="h-3.5 w-3.5" /> Last active: {u.last_active}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
